
//(function(window, $, PhotoSwipe){
	// $(function(){
	// 		
	// 		var options = {};
	// 		$("#media-gallery ul#Gallery a").photoSwipe(options);
	// 		console.log("fuck off its photoswipe");
	// 	
	// 	});
//}(window, window.jQuery, window.Code.PhotoSwipe));
