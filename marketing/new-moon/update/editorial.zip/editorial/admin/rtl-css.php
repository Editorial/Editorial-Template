/*
Theme Name:     Editorial Custom
Template:       <?php echo $this_theme_template, "\n"; ?>

Right to Left text support.
*/
@import url("../<?php echo $rtl_theme; ?>/rtl.css");