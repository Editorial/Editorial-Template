<?php

// ini_set('display_errors', 'On');
// error_reporting(E_ALL);

/**
 * Editorial Admin class
 *
 * @package     Editorial
 * @author      Miha Hribar
 * @copyright   Copyright (c) 2011, Editorial
 * @link        http://www.editorialtemplate.com
 * @version     1.0
 */
class Editorial_Admin
{
	/**
	 * Look & Feel page
	 */
	const PAGE_LOOK = 'look';

	/**
	 * Share page
	 */
	const PAGE_SHARE = 'sharing';

	/**
	 * Colopho page
	 */
	const PAGE_COLOPHON = 'colophon';

	const PAGE_CUSTOMIZE = 'customstyle';

	const CHILD_THEME = 'editorial-child';

	/**
	 * Pages users are allowed to include
	 *
	 * @var array
	 */
	private $_pages = array(
		self::PAGE_LOOK,
		self::PAGE_COLOPHON,
		self::PAGE_SHARE,
		self::PAGE_CUSTOMIZE,
	);

	/**
	 * Valid options
	 *
	 * @var array
	 */
	private $_options = array(
		'logo-big',
		'logo-small',
		'logo-gallery',
	    'favicon',
	    'touch-icon',
	    'typekit-token',
	    'typekit-kit',
		'black-and-white',
		'disable-admin-notices',
		'karma',
		'karma-treshold',
		'twitter-share',
		'twitter-account',
		'twitter-related',
		'facebook-share',
		'google-share',
		//'readability-share',
		'copyright',
		'child-theme',
	);

	/**
	 * Current page
	 *
	 * @var string
	 */
	private $_page;

	/**
	 * Constructor
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	public function __construct()
	{
		// setup admin menu
		add_action('admin_menu', array($this, 'menus'));
		
    // check for update and if the version is valid
    $this->checkUpdate();

    //if child theme was deleted, reset everything
    $has_child = Editorial::getOption( 'child-theme' );
    if ($has_child)
    {
    	$child_path = get_theme_root() .'/'. self::CHILD_THEME;
    	if ( !is_dir( $child_path ) )
    	{
    		Editorial::setOption('child-theme', false);
    	}
    	
    }
    
	}

	public function child_theme_deleted($data)
	{
		dump($data);
		return $data;
	}
	/**
	 * Add menu to wordpress administration
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	public function menus()
	{
		add_menu_page(
			'Editorial',
			'<strong>Edit</strong>orial',
			'administrator',
			'editorial',
			array($this, 'lookAndFeel'),
			get_bloginfo('template_directory').'/favicon.ico'
		);
		add_submenu_page(
			'editorial',
			'Look & Feel',
			'Look & Feel',
			'administrator',
			'editorial',
			array($this, 'lookAndFeel')
		);
		add_submenu_page(
			'editorial',
			'Sharing',
			'Sharing',
			'administrator',
			'editorial-'.self::PAGE_SHARE,
			array($this, 'sharing')
		);
		add_submenu_page(
			'editorial',
			'Colophon',
			'Colophon',
			'administrator',
			'editorial-'.self::PAGE_COLOPHON,
			array($this, 'colophon')
		);
		add_submenu_page(
			'editorial',
			'Customize',
			'Customize',
			'administrator',
			'editorial-'.self::PAGE_CUSTOMIZE,
			array($this, 'customize')
		);
	}

	/**
	 * Look &Feel
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	public function lookAndFeel()
	{
		// show look & feel page
		$this->_display(self::PAGE_LOOK);
	}

	/**
	 * Edit authors
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	public function colophon()
	{
		$this->_display(self::PAGE_COLOPHON);
	}

	/**
	 * Sharing settings
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	public function sharing()
	{
		$this->_display(self::PAGE_SHARE);
	}

	public function customize()
	{
		$this->_display(self::PAGE_CUSTOMIZE);
	}

	/**
	 * Display admin page
	 *
	 * @param  string $page page to display
	 * @return void
	 * @author Miha Hribar
	 */
	private function _display($page = '')
	{
		if (!in_array($page, $this->_pages) || !current_user_can('administrator'))
		{
			wp_die( __('You do not have sufficient permissions to access this page.'));
		}
		// display intended page
		$this->_page = $page;
		
		// force typekit?
		if (array_key_exists('typekit', $_GET))
		{
		    $this->typekit();
		}
		
	    // handle posts
		$this->_handlePost();
        
        // add font notice
        if (!Editorial::getOption('typekit-kit'))
        {
            add_action('admin_notices', array($this, 'fontNotice'));
        }
        
        // if black and white option is selected we need writable cache
        if (Editorial::getOption('black-and-white'))
        {
            if (!is_dir(WP_CACHE_DIR))
            {
                try
                {
                	Editorial::createPath(WP_CACHE_DIR, 0755);
                } 
                catch (Exception $e)
                {}
            }
            // can we cache now?
            if (!Editorial::canCache())
            {
                add_action('admin_notices', array($this, 'cacheNotice'));
            }
        }
		
		// include template settings page
		include 'settings.php';
	}
	
	/**
	 * Handle post
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	private function _handlePost()
	{
	    // handle posts
        if (is_array($_POST) && count($_POST))
        {
            $this->_save();
        }
	}

	/**
	 * Save form data
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	private function _save()
	{
		foreach ($_POST as $key => $value)
		{
			// make sure only allowed settings get in
			if (in_array($key, $this->_options))
			{
			    $typekit = false;
			    if ($key == 'typekit-token' && $value != Editorial::getOption('typekit-token'))
			    {
			        // run typekit
			        $typekit = true;
			    }
			    // save
				Editorial::setOption($key, $value);
				// run typekit setup
				if ($typekit)
				{
				    $this->typekit();
				}
			}
		}

		// on/off values are special
		switch ($this->_page)
		{
			case self::PAGE_LOOK:
				// checkboxes are special
				$checkboxes = array(
					'black-and-white',
					'disable-admin-notices',
					'karma',
				);
				$this->_handleCheckboxes($checkboxes);
				break;
			case self::PAGE_SHARE:
			    $checkboxes = array(
                    'twitter-share',
                    'facebook-share',
                    'google-share',
                    //'readability-share',
                );
                $this->_handleCheckboxes($checkboxes);
			    break;
			case self::PAGE_COLOPHON:
				// save current value for author ordering and titles
				if (!count($_POST['author']) || !count($_POST['title']) || count($_POST['title']) != count($_POST['author']))
				{
					// go away
					Editorial::setOption('authors', false);
					return;
				}
				$authors = array();
				foreach ($_POST['author'] as $order => $id)
				{
					$authors[$id] = $_POST['title'][$order];
				}
				Editorial::setOption('authors', $authors);
				break;
			case self::PAGE_CUSTOMIZE:
				if ($_POST['create-theme']) {
					Editorial::setOption('child-theme', true);
					//create child theme
					$this->_create_child_theme();
				}
				elseif($_POST['child-style-update'])
				{
					//Editorial::setOption('child-theme', false);
					$this->_update_custom_style($_POST['child-style-update']);
				}
				break;

		}
	}

	private function _update_custom_style( $css )
	{
		$theme_root = get_theme_root();
  	//ATTENTION, This is hardcoded and it is assuming the child theme is in dir editorial-child
  	$style_path = $theme_root.'/editorial-child/style.css';
  	file_put_contents( $style_path, stripcslashes($css) );

	}

	private function _create_child_theme()
	{
		$this_theme_title = get_current_theme();
		$this_theme_template = get_template();
		$this_theme_name = get_stylesheet();

		$child_theme_name = self::CHILD_THEME;

		$theme_root = get_theme_root();

		// Validate theme name
		$new_theme_path = $theme_root.'/'.$child_theme_name;
		if ( file_exists( $child_theme_name ) ) {
			return new WP_Error( 'exists', __( 'Theme directory already exists' ) );
		}

		mkdir( $new_theme_path );

		// Make style.css
		ob_start();
		require dirname(__FILE__).'/editorial-custom-css.php';
		$css = ob_get_clean();
		file_put_contents( $new_theme_path.'/style.css', $css );

		// Copy screenshot
		$parent_theme_screenshot = $theme_root.'/'.$this_theme_name.'/screenshot.png';
		if ( file_exists( $parent_theme_screenshot ) ) {
			copy( $parent_theme_screenshot, $new_theme_path.'/screenshot.png' );
		} elseif (file_exists( $parent_theme_screenshot = $theme_root.'/'.$this_theme_template.'/screenshot.png' ) ) {
			copy( $parent_theme_screenshot, $new_theme_path.'/screenshot.png' );
		}

		$allowed_themes = get_site_option( 'allowedthemes' );
		$allowed_themes[ $child_theme_name ] = true;
		update_site_option( 'allowedthemes', $allowed_themes );

		switch_theme( $this_theme_template, $child_theme_name );

	}
	
	/**
	 * Handle checkboxes
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	private function _handleCheckboxes($checkboxes)
	{
        foreach ($checkboxes as $check)
        {
            if (!isset($_POST[$check]))
            {
                Editorial::setOption($check, false);
            }
        }
	}

	/**
	 * Add notice that fonts are not enabled
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	public function fontNotice()
	{
		// notices can be disabled
		if (Editorial::getOption('disable-admin-notices')) return;
		$this->_showNotice(__('<strong>Editorial Typekit fonts are currently disabled.</strong> <a href="admin.php?page=editorial">Enable them</a> to get the most out of the Editorial theme.'));
	}
	
	/**
	 * Show cache notice
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	public function cacheNotice()
	{
		$this->_showNotice(__('<strong>Cache folder is missing or not writable</strong>. Please make sure the cache folder, located in <code>/wp-content/cache</code> exists and is writable by the server.')." ");
	}

	/**
	 * Check if an update is available
	 * -------------------------------
	 * DISCLAMER: By changing any of the code in this method you are voiding the agreement
	 * you have entered in with editorialtemplate.com and are liable for legal actions.
	 * And further more you are stealing money from honest developers trying to make
	 * a living with something awesome. Shame on you.
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	private function _checkVersion($data)
	{
		// notices can be disabled
		if ($data !== false)
		{
			if (!is_array($data) || !isset($data['valid']) || !$data['valid'])
			{
				add_action('admin_notices', array($this, 'invalidNotice'));
				return false;
			}
			// update available?
			if (is_array($data) && isset($data['new_version']) && EDITORIAL_VERSION != $data['new_version'])
			{
			    if (!Editorial::getOption('disable-admin-notices')) {
						add_action('admin_notices', array($this, 'updateNotice'));
					}
					return true;
			}
		}
	}

	public function checkUpdate()
	{
		//$url = parse_url( get_bloginfo('url') );

		//if( !$url['host'] == 'localhost') {
			add_filter('pre_set_site_transient_update_themes', array($this, 'check_for_update'));
			add_filter('themes_api', array($this, 'my_theme_api_call'), 10, 3);
		//}
	}
	
	public function check_for_update($checked_data)
	{
		global $wp_version;

		if(function_exists('wp_get_theme')){
		  $theme_data = wp_get_theme(get_option('template'));
		  $theme_version = $theme_data->Version;  
		} else {
		  $theme_data = get_theme_data( TEMPLATEPATH . '/style.css');
		  $theme_version = $theme_data['Version'];
		}    
		$theme_base = get_option('template');

		$request = array(
			'slug' => $theme_base,
			'version' => $theme_version 
		);
		// Start checking for an update
		$send_for_check = array(
			'body' => array(
				'action' => 'theme_update', 
				'request' => serialize($request),
				'api-key' => md5(get_bloginfo('url')),
				'blog-url' => get_bloginfo('url') //site_url() 
			),
			'user-agent' => 'WordPress/' . $wp_version . '; ' . get_bloginfo('url')
		);
		$raw_response = wp_remote_post(EDITORIAL_UPDATE_API, $send_for_check);
		if (!is_wp_error($raw_response) && ($raw_response['response']['code'] == 200))
			$response = unserialize($raw_response['body']);

		// Feed the update data into WP updater
		if (!empty($response)) {
			$checked_data->response[$theme_base] = $response;
			//var_dump($response);
			if (! $this->_checkVersion($response))
			{
				return false;
			}

		}

		return $checked_data;

	}

	public function my_theme_api_call($def, $action, $args)
	{
		if(function_exists('wp_get_theme')){
		  $theme_data = wp_get_theme(get_option('template'));
		  $theme_version = $theme_data->Version;  
		} else {
		  $theme_data = get_theme_data( TEMPLATEPATH . '/style.css');
		  $theme_version = $theme_data['Version'];
		}    
		$theme_base = get_option('template');
	
		if ($args->slug != $theme_base)
			return false;
		
		// Get the current version

		$args->version = $theme_version;
		$request_string = prepare_request($action, $args);
		$request = wp_remote_post(EDITORIAL_UPDATE_API, $request_string);

		if (is_wp_error($request)) {
			$res = new WP_Error('themes_api_failed', __('An Unexpected HTTP Error occurred during the API request.</p> <p><a href="?" onclick="document.location.reload(); return false;">Try again</a>'), $request->get_error_message());
		} else {
			$res = unserialize($request['body']);
			
			if ($res === false)
				$res = new WP_Error('themes_api_failed', __('An unknown error occurred'), $request['body']);
		}
		
		return $res;

	}

	/**
	 * Add notice that an update is available
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	public function updateNotice()
	{
	    if (Editorial::getOption('disable-admin-notices')) return;
		$msg = sprintf("<strong>Editorial theme update is available.</strong> You can update it through the <a href='%s/wp-admin/update-core.php'>Updates</a> section in the Admin", get_bloginfo('url'));
		$this->_showNotice(__($msg, 'Editorial'));
	}

	/**
	 * Add notice that an update is available
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	public function invalidNotice()
	{
		$this->_showNotice(__('<strong>You are using an ilegal copy of the Editorial theme</strong>. You can purchase additional licences on <a href="http://editorialtemplate.com/purchase">editorialtemplate.com</a>. Your domain has been logged in our system for investigation.', 'Editorial'));
	}
	
	/**
	 * Show notice
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	private function _showNotice($notice)
	{
		echo "<div class='updated fade'><p>".$notice."</p></div>";
	}

	/**
	 * Display user in administration. Outputs a list item.
	 *
	 * @param  Object $user
	 * @param  string $title
	 * @param  bool   $checked
	 * @return void
	 * @author Miha Hribar
	 */
	public static function displayUser($user, $title = '', $checked = true)
	{
		printf('<li id="user_%1$d">
					<span class="handle">handle</span>
					<input type="checkbox" name="author[]" value="%1$d"%4$s />
					<strong>%2$s</strong>
					<input type="text" name="title[]" value="%3$s" placeholder="Author title" />
				</li>', $user->ID, $user->display_name, $title, $checked ? ' checked="checked"' : '');
	}
	
	/**
	 * Generate a new editorial kit on typekit
	 *
	 * @return bool true on success, false on error
	 * @author Miha Hribar
	 */
	public function typekit()
	{
		// make sure we have token
		if (!Editorial::getOption('typekit-token') || strlen(Editorial::getOption('typekit-token')) < 20)
		{
		    return false;
		}
		// check if kit already exists
		if (Editorial::getOption('typekit-kit'))
		{
		    // fetch info about kit
		    $this->_typekitCheckKit();
		}
	    // create & publish new kit for domain with MinionPro
		else
		{
            $this->_typekitCreateKit();
		}
	}
	
    /**
     * Fetch typekit info
     *
     * @return bool
     * @author Miha Hribar
     */
    private function _typekitCheckKit()
    {
    	list($code, $response) = $this->_typekitAPICall(sprintf('kits/%s/', Editorial::getOption('typekit-kit')));
    	if ($code != 200)
    	{
    	    // remove kit
    	    Editorial::setOption('typekit-kit', false);
    	}
    	else
    	{
    	    $data = json_decode($response, true);
    	    if (is_array($data) && isset($data['kit']) && !isset($data['kit']['published']))
    	    {
    	        // publish kit
    	        $this->_typekitPublish();
    	    }
    	}
    }
	
	/**
	 * Create typekit kit with MinionPro
	 *
	 * @param  string $call API call path
	 * @return void
	 * @author Miha Hribar
	 */
	private function _typekitCreateKit()
	{
	    $params = array(
	       'name' => sprintf('%s (Editorial)', get_bloginfo('name')),
	       'domains' => sprintf('%s, 127.0.0.1', home_url()),
	       'badge' => false,
	       'families' => array(
	           array(
    	           'id' => 'nljb' // Minion Pro
    	           //'id' => 'gkmg' // Droid Sans
	           ),
	       ),
	    );
	    
	    list($code, $response) = $this->_typekitAPICall('kits', $params);
	    $data = json_decode($response, true);
	    if ($code != 200)
	    {
	        $this->_showNotice(sprintf(__('<strong>Error!</strong> Typekit fonts were not enabled. Reason: %s.', 'Editorial'), implode(' ', $data['errors'])));
	        return;
	    }
	    // success?
	    if (is_array($data) && isset($data['kit']) && isset($data['kit']['id']))
	    {
	        // save id
	        Editorial::setOption('typekit-kit', $data['kit']['id']);
	        // publish
	        $this->_typekitPublish();
	    }
	}
	
	/**
	 * Publish kit
	 *
	 * @return void
	 * @author Miha Hribar
	 */
	private function _typekitPublish()
	{
		list($code, $response) = $this->_typekitAPICall(sprintf('kits/%s/publish', Editorial::getOption('typekit-kit')), true);
		$data = json_decode($response, true);
		if ($code != 200)
		{
		    $this->_showNotice(sprintf(__('<strong>Error!</strong> Typekit kit was created but not published. Reason: %s.', 'Editorial'), implode(' ', $data['errors'])));
            return;
		}
		else
		{
		    $this->_showNotice(sprintf(__('<strong>Success!</strong> Typekit font has been created and is being published as we speak. Should take a couple of minutes to see the difference on your website so keep your pants on.')));
		}
	}
	
	/**
	 * Typekit API call
	 *
	 * @param  string $call
	 * @param  Array $params Call params
	 * @return array array of $code and $body
	 * @author Miha Hribar
	 */
	private function _typekitAPICall($call, $params = false)
	{
	    $url = sprintf(
           'https://typekit.com/api/v1/json/%s',
           $call
        );
        
	    // setup curl
		$ch = curl_init($url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(sprintf('X-Typekit-Token:%s', Editorial::getOption('typekit-token'))));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // if we have params create post request
        if ($params)
        {
            curl_setopt($ch, CURLOPT_POST, 1);
            if (is_array($params) && count($params))
            {
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
            }
        }
        // execute request
        $result = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return array($code, $result);
	}
}

// add admin capabilites
$Editorial = new Editorial_Admin();



?>