<div id="postbox-container-1" class="postbox-container">  
<div id="side-sortables" class="meta-box-sortables ui-sortable">

<div class="postbox " style="display: block; ">
  <div class="handlediv" title="Click to toggle"><br></div>
  <h3 class="hndle"><span><?php _e('FAQ', 'Editorial'); ?></span></h3>
  <div class="inside">
    <div class="table table_content">

      <p><a href="#">Link one<a></p>
      <p><a href="#">Link two<a></p>
      <p><a href="#">Link three<a></p>

    </div>
  </div>
 </div>

</div>
</div>
