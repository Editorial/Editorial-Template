Editorial theme (1.0)

Installation:

1. Open the .zip file and upload the folder to your ‘wp-content/themes directory’.
2. Log in to the admin area of your Wordpress website and select the Appearance tab. The new Editorial theme should be visible, under the ‘Available Themes’ heading. Select ‘Activate’ to begin using the theme.

Customisation:
